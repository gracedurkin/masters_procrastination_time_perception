﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2026.1.3),
    on outubro 02, 2026, at 16:16
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2026.1.3'
expName = 'procrastination_timeperception'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1536, 864]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\grace\\Desktop\\procrastination_timeperception\\experimento_completo_grace_lastrun.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    # store pilot mode in data file
    thisExp.addData('piloting', PILOTING, priority=priority.LOW)
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color=[0.8824, 0.9451, 1.0000], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0.8824, 0.9451, 1.0000]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Calibrando, aguarde um momento...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    # Setup iohub experiment
    ioConfig['Experiment'] = dict(filename=thisExp.dataFileName)
    
    # Start ioHub server
    ioServer = io.launchHubServer(window=win, **ioConfig)
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "Start" ---
    start = visual.TextStim(win=win, name='start',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=1.0, wrapWidth=1.5, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    start_stop = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "PPS" ---
    pergunta_pps = visual.TextStim(win=win, name='pergunta_pps',
        text='',
        font='Arial',
        pos=(0, 0.2), draggable=False, height=0.05, wrapWidth=1.5, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_pps = keyboard.Keyboard(deviceName='defaultKeyboard')
    image_pps = visual.ImageStim(
        win=win,
        name='image_pps', 
        image='default.png', mask=None, anchor='center',
        ori=0.0, pos=(0, -0.1), draggable=False, size=(1, 0.25),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    
    # --- Initialize components for Routine "MCQ_Instructions" ---
    text_mcq_inst = visual.TextStim(win=win, name='text_mcq_inst',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=1.0, wrapWidth=1.5, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_mcq_inst = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "MCQ_Instructions2" ---
    text_mcq_inst2 = visual.TextStim(win=win, name='text_mcq_inst2',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.04, wrapWidth=1.5, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_mcq_inst2 = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "MCQ" ---
    text_agora = visual.TextStim(win=win, name='text_agora',
        text='',
        font='Arial',
        pos=(-0.4, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_ou = visual.TextStim(win=win, name='text_ou',
        text='',
        font='Arial',
        pos=(-0.08, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[0.4431, 0.0510, -0.9137], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    text_depois = visual.TextStim(win=win, name='text_depois',
        text='',
        font='Arial',
        pos=(0.35, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-2.0);
    key_resp_MCQ = keyboard.Keyboard(deviceName='defaultKeyboard')
    mcq_teclaq = visual.TextStim(win=win, name='mcq_teclaq',
        text='',
        font='Arial',
        pos=(-0.4, -0.25), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[0.3255, 0.3255, 0.3255], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-6.0);
    mcq_teclap = visual.TextStim(win=win, name='mcq_teclap',
        text='',
        font='Arial',
        pos=(0.37, -0.28), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[0.3255, 0.3255, 0.3255], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-7.0);
    
    # --- Initialize components for Routine "spacer_mcq" ---
    spacer_MCQ = visual.TextStim(win=win, name='spacer_MCQ',
        text=None,
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "TB_Instructions" ---
    text_TB_Inst = visual.TextStim(win=win, name='text_TB_Inst',
        text='Nesta última tarefa, você ouvirá diferentes sons e precisará classificá-los como curtos ou longos, pressionando a tecla correspondente no teclado.\n\nPor favor siga as instruções na tela, tente responder o mais precisamente possível.\n\nPressione a barra de espaço para avançar.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=1.5, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_TB_Inst = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "TB_Inst_phase1" ---
    text_TB1_inst = visual.TextStim(win=win, name='text_TB1_inst',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=1.5, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_stop_inst = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "TB_phase1" ---
    text_fixation1 = visual.TextStim(win=win, name='text_fixation1',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    text_teclaq = visual.TextStim(win=win, name='text_teclaq',
        text='CURTO (TECLA Q)',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-1.0);
    # set audio backend
    sound.Sound.backend = 'ptb'
    sound_q = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker=None,    name='sound_q'
    )
    sound_q.setVolume(1.0)
    text_fixation2 = visual.TextStim(win=win, name='text_fixation2',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-3.0);
    text_teclap = visual.TextStim(win=win, name='text_teclap',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=-4.0);
    sound_p = sound.Sound(
        'A', 
        secs=2, 
        stereo=True, 
        hamming=True, 
        speaker=None,    name='sound_p'
    )
    sound_p.setVolume(1.0)
    
    # --- Initialize components for Routine "TB_Inst_phase2" ---
    text_TB2_inst = visual.TextStim(win=win, name='text_TB2_inst',
        text='Agora, você ouvirá os mesmos sons que aprendeu na fase anterior, mas em uma ordem aleatória.\n\nSeu objetivo é classificar cada som como curto ou longo, pressionando as teclas correspondentes: Q → Curto OU P → Longo\n\nVocê terá 10 segundos após ouvir o som para decidir e pressionar a tecla. Esta fase terminará assim que você acertar dez respostas corretas.\n\nClique na barra de espaço para avançar.',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_TBinst2_stop = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "spacer_phase2" ---
    text_fixation_phase2 = visual.TextStim(win=win, name='text_fixation_phase2',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "trial_phase2" ---
    sound_phase2 = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker=None,    name='sound_phase2'
    )
    sound_phase2.setVolume(1.0)
    
    # --- Initialize components for Routine "response_phase2" ---
    text_resp_phase2 = visual.TextStim(win=win, name='text_resp_phase2',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_phase2 = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "TB_Inst_phase3" ---
    text_TB3_inst = visual.TextStim(win=win, name='text_TB3_inst',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_inst_phase3 = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "spacer_phase3" ---
    text_spacer_phase3 = visual.TextStim(win=win, name='text_spacer_phase3',
        text='+',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    
    # --- Initialize components for Routine "trial_phase3" ---
    sound_phase3 = sound.Sound(
        'A', 
        secs=-1, 
        stereo=True, 
        hamming=True, 
        speaker=None,    name='sound_phase3'
    )
    sound_phase3.setVolume(1.0)
    
    # --- Initialize components for Routine "response_phase3" ---
    text_response_phase3 = visual.TextStim(win=win, name='text_response_phase3',
        text='',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.05, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    key_resp_phase3 = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # --- Initialize components for Routine "End" ---
    text_end = visual.TextStim(win=win, name='text_end',
        text='Você terminou a tarefa, agradeçemos por participar!\n',
        font='Arial',
        pos=(0, 0), draggable=False, height=0.06, wrapWidth=None, ori=0.0, 
        color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    end_key = keyboard.Keyboard(deviceName='defaultKeyboard')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "Start" ---
    # create an object to store info about Routine Start
    Start = data.Routine(
        name='Start',
        components=[start, start_stop],
    )
    Start.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    start.setText('Bem vindo(a) ao experimento.\n\nA seguir, você encontrará uma série de afirmações sobre hábitos de procrastinação. Para cada uma, avalie com que frequência você se comporta da maneira descrita. Responda de acordo com o que melhor reflete seu comportamento.\n\nAs cinco opções de resposta aparecerão na tela. Utilize as teclas 1 a 5 do teclado para escolher sua resposta. \n\nPressione a barra de espaço quando estiver pronto para começar.')
    start.setHeight(0.04)
    # create starting attributes for start_stop
    start_stop.keys = []
    start_stop.rt = []
    _start_stop_allKeys = []
    # store start times for Start
    Start.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Start.tStart = globalClock.getTime(format='float')
    Start.status = STARTED
    thisExp.addData('Start.started', Start.tStart)
    Start.maxDuration = None
    # keep track of which components have finished
    StartComponents = Start.components
    for thisComponent in Start.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Start" ---
    thisExp.currentRoutine = Start
    Start.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 200.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *start* updates
        
        # if start is starting this frame...
        if start.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            start.frameNStart = frameN  # exact frame index
            start.tStart = t  # local t and not account for scr refresh
            start.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(start, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'start.started')
            # update status
            start.status = STARTED
            start.setAutoDraw(True)
        
        # if start is active this frame...
        if start.status == STARTED:
            # update params
            pass
        
        # if start is stopping this frame...
        if start.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > start.tStartRefresh + 200.0-frameTolerance:
                # keep track of stop time/frame for later
                start.tStop = t  # not accounting for scr refresh
                start.tStopRefresh = tThisFlipGlobal  # on global time
                start.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'start.stopped')
                # update status
                start.status = FINISHED
                start.setAutoDraw(False)
        
        # *start_stop* updates
        waitOnFlip = False
        
        # if start_stop is starting this frame...
        if start_stop.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            start_stop.frameNStart = frameN  # exact frame index
            start_stop.tStart = t  # local t and not account for scr refresh
            start_stop.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(start_stop, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'start_stop.started')
            # update status
            start_stop.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(start_stop.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(start_stop.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if start_stop is stopping this frame...
        if start_stop.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > start_stop.tStartRefresh + 200-frameTolerance:
                # keep track of stop time/frame for later
                start_stop.tStop = t  # not accounting for scr refresh
                start_stop.tStopRefresh = tThisFlipGlobal  # on global time
                start_stop.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'start_stop.stopped')
                # update status
                start_stop.status = FINISHED
                start_stop.status = FINISHED
        if start_stop.status == STARTED and not waitOnFlip:
            theseKeys = start_stop.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _start_stop_allKeys.extend(theseKeys)
            if len(_start_stop_allKeys):
                start_stop.keys = _start_stop_allKeys[-1].name  # just the last key pressed
                start_stop.rt = _start_stop_allKeys[-1].rt
                start_stop.duration = _start_stop_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Start,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Start.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Start.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Start.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Start" ---
    for thisComponent in Start.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Start
    Start.tStop = globalClock.getTime(format='float')
    Start.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Start.stopped', Start.tStop)
    # check responses
    if start_stop.keys in ['', [], None]:  # No response was made
        start_stop.keys = None
    thisExp.addData('start_stop.keys',start_stop.keys)
    if start_stop.keys != None:  # we had a response
        thisExp.addData('start_stop.rt', start_stop.rt)
        thisExp.addData('start_stop.duration', start_stop.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if Start.maxDurationReached:
        routineTimer.addTime(-Start.maxDuration)
    elif Start.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-200.000000)
    thisExp.nextEntry()
    
    # set up handler to look after randomisation of conditions etc
    trials_pps = data.TrialHandler2(
        name='trials_pps',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('perguntas copy.csv'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trials_pps)  # add the loop to the experiment
    thisTrials_pp = trials_pps.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_pp.rgb)
    if thisTrials_pp != None:
        for paramName in thisTrials_pp:
            globals()[paramName] = thisTrials_pp[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_pp in trials_pps:
        trials_pps.status = STARTED
        if hasattr(thisTrials_pp, 'status'):
            thisTrials_pp.status = STARTED
        currentLoop = trials_pps
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_pp.rgb)
        if thisTrials_pp != None:
            for paramName in thisTrials_pp:
                globals()[paramName] = thisTrials_pp[paramName]
        
        # --- Prepare to start Routine "PPS" ---
        # create an object to store info about Routine PPS
        PPS = data.Routine(
            name='PPS',
            components=[pergunta_pps, key_resp_pps, image_pps],
        )
        PPS.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        pergunta_pps.setText(pergunta)
        # create starting attributes for key_resp_pps
        key_resp_pps.keys = []
        key_resp_pps.rt = []
        _key_resp_pps_allKeys = []
        image_pps.setImage('pps_scale.png')
        # store start times for PPS
        PPS.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        PPS.tStart = globalClock.getTime(format='float')
        PPS.status = STARTED
        thisExp.addData('PPS.started', PPS.tStart)
        PPS.maxDuration = None
        # keep track of which components have finished
        PPSComponents = PPS.components
        for thisComponent in PPS.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "PPS" ---
        thisExp.currentRoutine = PPS
        PPS.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 120.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_pp, 'status') and thisTrials_pp.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *pergunta_pps* updates
            
            # if pergunta_pps is starting this frame...
            if pergunta_pps.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                pergunta_pps.frameNStart = frameN  # exact frame index
                pergunta_pps.tStart = t  # local t and not account for scr refresh
                pergunta_pps.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(pergunta_pps, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'pergunta_pps.started')
                # update status
                pergunta_pps.status = STARTED
                pergunta_pps.setAutoDraw(True)
            
            # if pergunta_pps is active this frame...
            if pergunta_pps.status == STARTED:
                # update params
                pass
            
            # if pergunta_pps is stopping this frame...
            if pergunta_pps.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > pergunta_pps.tStartRefresh + 120.0-frameTolerance:
                    # keep track of stop time/frame for later
                    pergunta_pps.tStop = t  # not accounting for scr refresh
                    pergunta_pps.tStopRefresh = tThisFlipGlobal  # on global time
                    pergunta_pps.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'pergunta_pps.stopped')
                    # update status
                    pergunta_pps.status = FINISHED
                    pergunta_pps.setAutoDraw(False)
            
            # *key_resp_pps* updates
            waitOnFlip = False
            
            # if key_resp_pps is starting this frame...
            if key_resp_pps.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_pps.frameNStart = frameN  # exact frame index
                key_resp_pps.tStart = t  # local t and not account for scr refresh
                key_resp_pps.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_pps, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_pps.started')
                # update status
                key_resp_pps.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_pps.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_pps.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_resp_pps is stopping this frame...
            if key_resp_pps.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_resp_pps.tStartRefresh + 120.0-frameTolerance:
                    # keep track of stop time/frame for later
                    key_resp_pps.tStop = t  # not accounting for scr refresh
                    key_resp_pps.tStopRefresh = tThisFlipGlobal  # on global time
                    key_resp_pps.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_pps.stopped')
                    # update status
                    key_resp_pps.status = FINISHED
                    key_resp_pps.status = FINISHED
            if key_resp_pps.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_pps.getKeys(keyList=['1','2','3','4','5'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_pps_allKeys.extend(theseKeys)
                if len(_key_resp_pps_allKeys):
                    key_resp_pps.keys = _key_resp_pps_allKeys[-1].name  # just the last key pressed
                    key_resp_pps.rt = _key_resp_pps_allKeys[-1].rt
                    key_resp_pps.duration = _key_resp_pps_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # *image_pps* updates
            
            # if image_pps is starting this frame...
            if image_pps.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image_pps.frameNStart = frameN  # exact frame index
                image_pps.tStart = t  # local t and not account for scr refresh
                image_pps.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_pps, 'tStartRefresh')  # time at next scr refresh
                # update status
                image_pps.status = STARTED
                image_pps.setAutoDraw(True)
            
            # if image_pps is active this frame...
            if image_pps.status == STARTED:
                # update params
                pass
            
            # if image_pps is stopping this frame...
            if image_pps.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image_pps.tStartRefresh + 120.0-frameTolerance:
                    # keep track of stop time/frame for later
                    image_pps.tStop = t  # not accounting for scr refresh
                    image_pps.tStopRefresh = tThisFlipGlobal  # on global time
                    image_pps.frameNStop = frameN  # exact frame index
                    # update status
                    image_pps.status = FINISHED
                    image_pps.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=PPS,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                PPS.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if PPS.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in PPS.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "PPS" ---
        for thisComponent in PPS.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for PPS
        PPS.tStop = globalClock.getTime(format='float')
        PPS.tStopRefresh = tThisFlipGlobal
        thisExp.addData('PPS.stopped', PPS.tStop)
        # check responses
        if key_resp_pps.keys in ['', [], None]:  # No response was made
            key_resp_pps.keys = None
        trials_pps.addData('key_resp_pps.keys',key_resp_pps.keys)
        if key_resp_pps.keys != None:  # we had a response
            trials_pps.addData('key_resp_pps.rt', key_resp_pps.rt)
            trials_pps.addData('key_resp_pps.duration', key_resp_pps.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if PPS.maxDurationReached:
            routineTimer.addTime(-PPS.maxDuration)
        elif PPS.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-120.000000)
        # mark thisTrials_pp as finished
        if hasattr(thisTrials_pp, 'status'):
            thisTrials_pp.status = FINISHED
        # if awaiting a pause, pause now
        if trials_pps.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials_pps.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trials_pps'
    trials_pps.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "MCQ_Instructions" ---
    # create an object to store info about Routine MCQ_Instructions
    MCQ_Instructions = data.Routine(
        name='MCQ_Instructions',
        components=[text_mcq_inst, key_resp_mcq_inst],
    )
    MCQ_Instructions.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    text_mcq_inst.setText('Agora nesta segunda tarefa, você verá várias duplas de recompensas em dinheiro que são hipotéticas, ou seja, não serão pagas de fato. Elas servem apenas para entendermos como você tomaria decisões em situações reais.\n\nEm cada dupla, você deverá escolher entre receber um valor de imediato ou receber um valor maior, mas que estaria disponível somente após esperar um certo tempo.\n\nExemplo: 50 reais hoje ou 75 reais em 30 dias (esperar 30 dias para receber o valor maior).\n\nClique na barra de espaço para avançar.')
    text_mcq_inst.setHeight(0.04)
    # create starting attributes for key_resp_mcq_inst
    key_resp_mcq_inst.keys = []
    key_resp_mcq_inst.rt = []
    _key_resp_mcq_inst_allKeys = []
    # store start times for MCQ_Instructions
    MCQ_Instructions.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    MCQ_Instructions.tStart = globalClock.getTime(format='float')
    MCQ_Instructions.status = STARTED
    thisExp.addData('MCQ_Instructions.started', MCQ_Instructions.tStart)
    MCQ_Instructions.maxDuration = None
    # keep track of which components have finished
    MCQ_InstructionsComponents = MCQ_Instructions.components
    for thisComponent in MCQ_Instructions.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "MCQ_Instructions" ---
    thisExp.currentRoutine = MCQ_Instructions
    MCQ_Instructions.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 120.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_mcq_inst* updates
        
        # if text_mcq_inst is starting this frame...
        if text_mcq_inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_mcq_inst.frameNStart = frameN  # exact frame index
            text_mcq_inst.tStart = t  # local t and not account for scr refresh
            text_mcq_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_mcq_inst, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_mcq_inst.started')
            # update status
            text_mcq_inst.status = STARTED
            text_mcq_inst.setAutoDraw(True)
        
        # if text_mcq_inst is active this frame...
        if text_mcq_inst.status == STARTED:
            # update params
            pass
        
        # if text_mcq_inst is stopping this frame...
        if text_mcq_inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_mcq_inst.tStartRefresh + 120-frameTolerance:
                # keep track of stop time/frame for later
                text_mcq_inst.tStop = t  # not accounting for scr refresh
                text_mcq_inst.tStopRefresh = tThisFlipGlobal  # on global time
                text_mcq_inst.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_mcq_inst.stopped')
                # update status
                text_mcq_inst.status = FINISHED
                text_mcq_inst.setAutoDraw(False)
        
        # *key_resp_mcq_inst* updates
        waitOnFlip = False
        
        # if key_resp_mcq_inst is starting this frame...
        if key_resp_mcq_inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_mcq_inst.frameNStart = frameN  # exact frame index
            key_resp_mcq_inst.tStart = t  # local t and not account for scr refresh
            key_resp_mcq_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_mcq_inst, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_mcq_inst.started')
            # update status
            key_resp_mcq_inst.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_mcq_inst.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_mcq_inst.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_resp_mcq_inst is stopping this frame...
        if key_resp_mcq_inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_resp_mcq_inst.tStartRefresh + 120-frameTolerance:
                # keep track of stop time/frame for later
                key_resp_mcq_inst.tStop = t  # not accounting for scr refresh
                key_resp_mcq_inst.tStopRefresh = tThisFlipGlobal  # on global time
                key_resp_mcq_inst.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_mcq_inst.stopped')
                # update status
                key_resp_mcq_inst.status = FINISHED
                key_resp_mcq_inst.status = FINISHED
        if key_resp_mcq_inst.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_mcq_inst.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_mcq_inst_allKeys.extend(theseKeys)
            if len(_key_resp_mcq_inst_allKeys):
                key_resp_mcq_inst.keys = _key_resp_mcq_inst_allKeys[-1].name  # just the last key pressed
                key_resp_mcq_inst.rt = _key_resp_mcq_inst_allKeys[-1].rt
                key_resp_mcq_inst.duration = _key_resp_mcq_inst_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=MCQ_Instructions,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            MCQ_Instructions.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if MCQ_Instructions.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in MCQ_Instructions.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "MCQ_Instructions" ---
    for thisComponent in MCQ_Instructions.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for MCQ_Instructions
    MCQ_Instructions.tStop = globalClock.getTime(format='float')
    MCQ_Instructions.tStopRefresh = tThisFlipGlobal
    thisExp.addData('MCQ_Instructions.stopped', MCQ_Instructions.tStop)
    # check responses
    if key_resp_mcq_inst.keys in ['', [], None]:  # No response was made
        key_resp_mcq_inst.keys = None
    thisExp.addData('key_resp_mcq_inst.keys',key_resp_mcq_inst.keys)
    if key_resp_mcq_inst.keys != None:  # we had a response
        thisExp.addData('key_resp_mcq_inst.rt', key_resp_mcq_inst.rt)
        thisExp.addData('key_resp_mcq_inst.duration', key_resp_mcq_inst.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if MCQ_Instructions.maxDurationReached:
        routineTimer.addTime(-MCQ_Instructions.maxDuration)
    elif MCQ_Instructions.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-120.000000)
    thisExp.nextEntry()
    
    # --- Prepare to start Routine "MCQ_Instructions2" ---
    # create an object to store info about Routine MCQ_Instructions2
    MCQ_Instructions2 = data.Routine(
        name='MCQ_Instructions2',
        components=[text_mcq_inst2, key_resp_mcq_inst2],
    )
    MCQ_Instructions2.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    text_mcq_inst2.setText('Use a tecla Q para escolher a opção "Agora" OU use a tecla P para escolher a opção "Depois". \n\n\nVocê terá 30 segundos para escolher a opção que prefere. Por favor, considere atentamente as opções antes de decidir.\n\n\nClique na barra de espaço quando estiver pronto(a) para começar.')
    # create starting attributes for key_resp_mcq_inst2
    key_resp_mcq_inst2.keys = []
    key_resp_mcq_inst2.rt = []
    _key_resp_mcq_inst2_allKeys = []
    # store start times for MCQ_Instructions2
    MCQ_Instructions2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    MCQ_Instructions2.tStart = globalClock.getTime(format='float')
    MCQ_Instructions2.status = STARTED
    thisExp.addData('MCQ_Instructions2.started', MCQ_Instructions2.tStart)
    MCQ_Instructions2.maxDuration = None
    # keep track of which components have finished
    MCQ_Instructions2Components = MCQ_Instructions2.components
    for thisComponent in MCQ_Instructions2.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "MCQ_Instructions2" ---
    thisExp.currentRoutine = MCQ_Instructions2
    MCQ_Instructions2.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 120.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_mcq_inst2* updates
        
        # if text_mcq_inst2 is starting this frame...
        if text_mcq_inst2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_mcq_inst2.frameNStart = frameN  # exact frame index
            text_mcq_inst2.tStart = t  # local t and not account for scr refresh
            text_mcq_inst2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_mcq_inst2, 'tStartRefresh')  # time at next scr refresh
            # update status
            text_mcq_inst2.status = STARTED
            text_mcq_inst2.setAutoDraw(True)
        
        # if text_mcq_inst2 is active this frame...
        if text_mcq_inst2.status == STARTED:
            # update params
            pass
        
        # if text_mcq_inst2 is stopping this frame...
        if text_mcq_inst2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_mcq_inst2.tStartRefresh + 120-frameTolerance:
                # keep track of stop time/frame for later
                text_mcq_inst2.tStop = t  # not accounting for scr refresh
                text_mcq_inst2.tStopRefresh = tThisFlipGlobal  # on global time
                text_mcq_inst2.frameNStop = frameN  # exact frame index
                # update status
                text_mcq_inst2.status = FINISHED
                text_mcq_inst2.setAutoDraw(False)
        
        # *key_resp_mcq_inst2* updates
        waitOnFlip = False
        
        # if key_resp_mcq_inst2 is starting this frame...
        if key_resp_mcq_inst2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_mcq_inst2.frameNStart = frameN  # exact frame index
            key_resp_mcq_inst2.tStart = t  # local t and not account for scr refresh
            key_resp_mcq_inst2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_mcq_inst2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_mcq_inst2.started')
            # update status
            key_resp_mcq_inst2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_mcq_inst2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_mcq_inst2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_resp_mcq_inst2 is stopping this frame...
        if key_resp_mcq_inst2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_resp_mcq_inst2.tStartRefresh + 120-frameTolerance:
                # keep track of stop time/frame for later
                key_resp_mcq_inst2.tStop = t  # not accounting for scr refresh
                key_resp_mcq_inst2.tStopRefresh = tThisFlipGlobal  # on global time
                key_resp_mcq_inst2.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_mcq_inst2.stopped')
                # update status
                key_resp_mcq_inst2.status = FINISHED
                key_resp_mcq_inst2.status = FINISHED
        if key_resp_mcq_inst2.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_mcq_inst2.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_mcq_inst2_allKeys.extend(theseKeys)
            if len(_key_resp_mcq_inst2_allKeys):
                key_resp_mcq_inst2.keys = _key_resp_mcq_inst2_allKeys[-1].name  # just the last key pressed
                key_resp_mcq_inst2.rt = _key_resp_mcq_inst2_allKeys[-1].rt
                key_resp_mcq_inst2.duration = _key_resp_mcq_inst2_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=MCQ_Instructions2,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            MCQ_Instructions2.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if MCQ_Instructions2.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in MCQ_Instructions2.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "MCQ_Instructions2" ---
    for thisComponent in MCQ_Instructions2.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for MCQ_Instructions2
    MCQ_Instructions2.tStop = globalClock.getTime(format='float')
    MCQ_Instructions2.tStopRefresh = tThisFlipGlobal
    thisExp.addData('MCQ_Instructions2.stopped', MCQ_Instructions2.tStop)
    # check responses
    if key_resp_mcq_inst2.keys in ['', [], None]:  # No response was made
        key_resp_mcq_inst2.keys = None
    thisExp.addData('key_resp_mcq_inst2.keys',key_resp_mcq_inst2.keys)
    if key_resp_mcq_inst2.keys != None:  # we had a response
        thisExp.addData('key_resp_mcq_inst2.rt', key_resp_mcq_inst2.rt)
        thisExp.addData('key_resp_mcq_inst2.duration', key_resp_mcq_inst2.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if MCQ_Instructions2.maxDurationReached:
        routineTimer.addTime(-MCQ_Instructions2.maxDuration)
    elif MCQ_Instructions2.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-120.000000)
    thisExp.nextEntry()
    
    # set up handler to look after randomisation of conditions etc
    trials_mcq = data.TrialHandler2(
        name='trials_mcq',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('Kirby_Conditions copy.csv'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trials_mcq)  # add the loop to the experiment
    thisTrials_mcq = trials_mcq.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_mcq.rgb)
    if thisTrials_mcq != None:
        for paramName in thisTrials_mcq:
            globals()[paramName] = thisTrials_mcq[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_mcq in trials_mcq:
        trials_mcq.status = STARTED
        if hasattr(thisTrials_mcq, 'status'):
            thisTrials_mcq.status = STARTED
        currentLoop = trials_mcq
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_mcq.rgb)
        if thisTrials_mcq != None:
            for paramName in thisTrials_mcq:
                globals()[paramName] = thisTrials_mcq[paramName]
        
        # --- Prepare to start Routine "MCQ" ---
        # create an object to store info about Routine MCQ
        MCQ = data.Routine(
            name='MCQ',
            components=[text_agora, text_ou, text_depois, key_resp_MCQ, mcq_teclaq, mcq_teclap],
        )
        MCQ.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        text_agora.setText('R$' + str(valor_imediato) + ' hoje'
        )
        text_ou.setText('ou')
        text_depois.setText('R$' + str(valor_adiado) + ' em ' + str(int(dias_atraso)) + ' dias'
        )
        # create starting attributes for key_resp_MCQ
        key_resp_MCQ.keys = []
        key_resp_MCQ.rt = []
        _key_resp_MCQ_allKeys = []
        mcq_teclaq.setText('( tecla Q )')
        mcq_teclap.setText('( tecla P )\n')
        # store start times for MCQ
        MCQ.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        MCQ.tStart = globalClock.getTime(format='float')
        MCQ.status = STARTED
        thisExp.addData('MCQ.started', MCQ.tStart)
        MCQ.maxDuration = None
        # keep track of which components have finished
        MCQComponents = MCQ.components
        for thisComponent in MCQ.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "MCQ" ---
        thisExp.currentRoutine = MCQ
        MCQ.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 30.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_mcq, 'status') and thisTrials_mcq.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_agora* updates
            
            # if text_agora is starting this frame...
            if text_agora.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_agora.frameNStart = frameN  # exact frame index
                text_agora.tStart = t  # local t and not account for scr refresh
                text_agora.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_agora, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_agora.started')
                # update status
                text_agora.status = STARTED
                text_agora.setAutoDraw(True)
            
            # if text_agora is active this frame...
            if text_agora.status == STARTED:
                # update params
                pass
            
            # if text_agora is stopping this frame...
            if text_agora.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_agora.tStartRefresh + 30-frameTolerance:
                    # keep track of stop time/frame for later
                    text_agora.tStop = t  # not accounting for scr refresh
                    text_agora.tStopRefresh = tThisFlipGlobal  # on global time
                    text_agora.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_agora.stopped')
                    # update status
                    text_agora.status = FINISHED
                    text_agora.setAutoDraw(False)
            
            # *text_ou* updates
            
            # if text_ou is starting this frame...
            if text_ou.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_ou.frameNStart = frameN  # exact frame index
                text_ou.tStart = t  # local t and not account for scr refresh
                text_ou.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_ou, 'tStartRefresh')  # time at next scr refresh
                # update status
                text_ou.status = STARTED
                text_ou.setAutoDraw(True)
            
            # if text_ou is active this frame...
            if text_ou.status == STARTED:
                # update params
                pass
            
            # if text_ou is stopping this frame...
            if text_ou.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_ou.tStartRefresh + 30.0-frameTolerance:
                    # keep track of stop time/frame for later
                    text_ou.tStop = t  # not accounting for scr refresh
                    text_ou.tStopRefresh = tThisFlipGlobal  # on global time
                    text_ou.frameNStop = frameN  # exact frame index
                    # update status
                    text_ou.status = FINISHED
                    text_ou.setAutoDraw(False)
            
            # *text_depois* updates
            
            # if text_depois is starting this frame...
            if text_depois.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_depois.frameNStart = frameN  # exact frame index
                text_depois.tStart = t  # local t and not account for scr refresh
                text_depois.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_depois, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_depois.started')
                # update status
                text_depois.status = STARTED
                text_depois.setAutoDraw(True)
            
            # if text_depois is active this frame...
            if text_depois.status == STARTED:
                # update params
                pass
            
            # if text_depois is stopping this frame...
            if text_depois.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_depois.tStartRefresh + 30-frameTolerance:
                    # keep track of stop time/frame for later
                    text_depois.tStop = t  # not accounting for scr refresh
                    text_depois.tStopRefresh = tThisFlipGlobal  # on global time
                    text_depois.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_depois.stopped')
                    # update status
                    text_depois.status = FINISHED
                    text_depois.setAutoDraw(False)
            
            # *key_resp_MCQ* updates
            waitOnFlip = False
            
            # if key_resp_MCQ is starting this frame...
            if key_resp_MCQ.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_MCQ.frameNStart = frameN  # exact frame index
                key_resp_MCQ.tStart = t  # local t and not account for scr refresh
                key_resp_MCQ.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_MCQ, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_MCQ.started')
                # update status
                key_resp_MCQ.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_MCQ.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_MCQ.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_resp_MCQ is stopping this frame...
            if key_resp_MCQ.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_resp_MCQ.tStartRefresh + 30-frameTolerance:
                    # keep track of stop time/frame for later
                    key_resp_MCQ.tStop = t  # not accounting for scr refresh
                    key_resp_MCQ.tStopRefresh = tThisFlipGlobal  # on global time
                    key_resp_MCQ.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_MCQ.stopped')
                    # update status
                    key_resp_MCQ.status = FINISHED
                    key_resp_MCQ.status = FINISHED
            if key_resp_MCQ.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_MCQ.getKeys(keyList=['q','p'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_MCQ_allKeys.extend(theseKeys)
                if len(_key_resp_MCQ_allKeys):
                    key_resp_MCQ.keys = _key_resp_MCQ_allKeys[-1].name  # just the last key pressed
                    key_resp_MCQ.rt = _key_resp_MCQ_allKeys[-1].rt
                    key_resp_MCQ.duration = _key_resp_MCQ_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            # Run 'Each Frame' code from code_resp_binaria
            if key_resp_MCQ.keys:  # Verifica se houve uma resposta
                if 'q' in key_resp_MCQ.keys:
                    resposta_binaria = 0
                elif 'p' in key_resp_MCQ.keys:
                    resposta_binaria = 1
            
            
            # *mcq_teclaq* updates
            
            # if mcq_teclaq is starting this frame...
            if mcq_teclaq.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                mcq_teclaq.frameNStart = frameN  # exact frame index
                mcq_teclaq.tStart = t  # local t and not account for scr refresh
                mcq_teclaq.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(mcq_teclaq, 'tStartRefresh')  # time at next scr refresh
                # update status
                mcq_teclaq.status = STARTED
                mcq_teclaq.setAutoDraw(True)
            
            # if mcq_teclaq is active this frame...
            if mcq_teclaq.status == STARTED:
                # update params
                pass
            
            # if mcq_teclaq is stopping this frame...
            if mcq_teclaq.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > mcq_teclaq.tStartRefresh + 30.0-frameTolerance:
                    # keep track of stop time/frame for later
                    mcq_teclaq.tStop = t  # not accounting for scr refresh
                    mcq_teclaq.tStopRefresh = tThisFlipGlobal  # on global time
                    mcq_teclaq.frameNStop = frameN  # exact frame index
                    # update status
                    mcq_teclaq.status = FINISHED
                    mcq_teclaq.setAutoDraw(False)
            
            # *mcq_teclap* updates
            
            # if mcq_teclap is starting this frame...
            if mcq_teclap.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                mcq_teclap.frameNStart = frameN  # exact frame index
                mcq_teclap.tStart = t  # local t and not account for scr refresh
                mcq_teclap.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(mcq_teclap, 'tStartRefresh')  # time at next scr refresh
                # update status
                mcq_teclap.status = STARTED
                mcq_teclap.setAutoDraw(True)
            
            # if mcq_teclap is active this frame...
            if mcq_teclap.status == STARTED:
                # update params
                pass
            
            # if mcq_teclap is stopping this frame...
            if mcq_teclap.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > mcq_teclap.tStartRefresh + 30-frameTolerance:
                    # keep track of stop time/frame for later
                    mcq_teclap.tStop = t  # not accounting for scr refresh
                    mcq_teclap.tStopRefresh = tThisFlipGlobal  # on global time
                    mcq_teclap.frameNStop = frameN  # exact frame index
                    # update status
                    mcq_teclap.status = FINISHED
                    mcq_teclap.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=MCQ,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                MCQ.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if MCQ.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in MCQ.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "MCQ" ---
        for thisComponent in MCQ.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for MCQ
        MCQ.tStop = globalClock.getTime(format='float')
        MCQ.tStopRefresh = tThisFlipGlobal
        thisExp.addData('MCQ.stopped', MCQ.tStop)
        # check responses
        if key_resp_MCQ.keys in ['', [], None]:  # No response was made
            key_resp_MCQ.keys = None
        trials_mcq.addData('key_resp_MCQ.keys',key_resp_MCQ.keys)
        if key_resp_MCQ.keys != None:  # we had a response
            trials_mcq.addData('key_resp_MCQ.rt', key_resp_MCQ.rt)
            trials_mcq.addData('key_resp_MCQ.duration', key_resp_MCQ.duration)
        # Run 'End Routine' code from code_mcq
        if key_resp_MCQ.keys:
            resposta = key_resp_MCQ.keys[0]
        else:
            resposta = 'no_response'
            
        # Salvar no arquivo de dados
        thisExp.addData('Resposta', resposta)
        thisExp.addData('Valor_Imediato', valor_imediato)
        thisExp.addData('Valor_Adiado', valor_adiado)
        thisExp.addData('Dias_Atraso', dias_atraso)
        
        
        # Run 'End Routine' code from code_resp_binaria
        thisExp.addData('Resposta_Binaria', resposta_binaria)
        
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if MCQ.maxDurationReached:
            routineTimer.addTime(-MCQ.maxDuration)
        elif MCQ.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-30.000000)
        
        # --- Prepare to start Routine "spacer_mcq" ---
        # create an object to store info about Routine spacer_mcq
        spacer_mcq = data.Routine(
            name='spacer_mcq',
            components=[spacer_MCQ],
        )
        spacer_mcq.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        spacer_MCQ.setText('')
        # store start times for spacer_mcq
        spacer_mcq.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        spacer_mcq.tStart = globalClock.getTime(format='float')
        spacer_mcq.status = STARTED
        thisExp.addData('spacer_mcq.started', spacer_mcq.tStart)
        spacer_mcq.maxDuration = None
        # keep track of which components have finished
        spacer_mcqComponents = spacer_mcq.components
        for thisComponent in spacer_mcq.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "spacer_mcq" ---
        thisExp.currentRoutine = spacer_mcq
        spacer_mcq.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_mcq, 'status') and thisTrials_mcq.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *spacer_MCQ* updates
            
            # if spacer_MCQ is starting this frame...
            if spacer_MCQ.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                spacer_MCQ.frameNStart = frameN  # exact frame index
                spacer_MCQ.tStart = t  # local t and not account for scr refresh
                spacer_MCQ.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(spacer_MCQ, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'spacer_MCQ.started')
                # update status
                spacer_MCQ.status = STARTED
                spacer_MCQ.setAutoDraw(True)
            
            # if spacer_MCQ is active this frame...
            if spacer_MCQ.status == STARTED:
                # update params
                pass
            
            # if spacer_MCQ is stopping this frame...
            if spacer_MCQ.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > spacer_MCQ.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    spacer_MCQ.tStop = t  # not accounting for scr refresh
                    spacer_MCQ.tStopRefresh = tThisFlipGlobal  # on global time
                    spacer_MCQ.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'spacer_MCQ.stopped')
                    # update status
                    spacer_MCQ.status = FINISHED
                    spacer_MCQ.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=spacer_mcq,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                spacer_mcq.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if spacer_mcq.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in spacer_mcq.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "spacer_mcq" ---
        for thisComponent in spacer_mcq.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for spacer_mcq
        spacer_mcq.tStop = globalClock.getTime(format='float')
        spacer_mcq.tStopRefresh = tThisFlipGlobal
        thisExp.addData('spacer_mcq.stopped', spacer_mcq.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if spacer_mcq.maxDurationReached:
            routineTimer.addTime(-spacer_mcq.maxDuration)
        elif spacer_mcq.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.500000)
        # mark thisTrials_mcq as finished
        if hasattr(thisTrials_mcq, 'status'):
            thisTrials_mcq.status = FINISHED
        # if awaiting a pause, pause now
        if trials_mcq.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials_mcq.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trials_mcq'
    trials_mcq.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "TB_Instructions" ---
    # create an object to store info about Routine TB_Instructions
    TB_Instructions = data.Routine(
        name='TB_Instructions',
        components=[text_TB_Inst, key_resp_TB_Inst],
    )
    TB_Instructions.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_resp_TB_Inst
    key_resp_TB_Inst.keys = []
    key_resp_TB_Inst.rt = []
    _key_resp_TB_Inst_allKeys = []
    # store start times for TB_Instructions
    TB_Instructions.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    TB_Instructions.tStart = globalClock.getTime(format='float')
    TB_Instructions.status = STARTED
    thisExp.addData('TB_Instructions.started', TB_Instructions.tStart)
    TB_Instructions.maxDuration = None
    # keep track of which components have finished
    TB_InstructionsComponents = TB_Instructions.components
    for thisComponent in TB_Instructions.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "TB_Instructions" ---
    thisExp.currentRoutine = TB_Instructions
    TB_Instructions.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 200.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_TB_Inst* updates
        
        # if text_TB_Inst is starting this frame...
        if text_TB_Inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_TB_Inst.frameNStart = frameN  # exact frame index
            text_TB_Inst.tStart = t  # local t and not account for scr refresh
            text_TB_Inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_TB_Inst, 'tStartRefresh')  # time at next scr refresh
            # update status
            text_TB_Inst.status = STARTED
            text_TB_Inst.setAutoDraw(True)
        
        # if text_TB_Inst is active this frame...
        if text_TB_Inst.status == STARTED:
            # update params
            pass
        
        # if text_TB_Inst is stopping this frame...
        if text_TB_Inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_TB_Inst.tStartRefresh + 200-frameTolerance:
                # keep track of stop time/frame for later
                text_TB_Inst.tStop = t  # not accounting for scr refresh
                text_TB_Inst.tStopRefresh = tThisFlipGlobal  # on global time
                text_TB_Inst.frameNStop = frameN  # exact frame index
                # update status
                text_TB_Inst.status = FINISHED
                text_TB_Inst.setAutoDraw(False)
        
        # *key_resp_TB_Inst* updates
        waitOnFlip = False
        
        # if key_resp_TB_Inst is starting this frame...
        if key_resp_TB_Inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_TB_Inst.frameNStart = frameN  # exact frame index
            key_resp_TB_Inst.tStart = t  # local t and not account for scr refresh
            key_resp_TB_Inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_TB_Inst, 'tStartRefresh')  # time at next scr refresh
            # update status
            key_resp_TB_Inst.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_TB_Inst.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_TB_Inst.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_resp_TB_Inst is stopping this frame...
        if key_resp_TB_Inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_resp_TB_Inst.tStartRefresh + 200-frameTolerance:
                # keep track of stop time/frame for later
                key_resp_TB_Inst.tStop = t  # not accounting for scr refresh
                key_resp_TB_Inst.tStopRefresh = tThisFlipGlobal  # on global time
                key_resp_TB_Inst.frameNStop = frameN  # exact frame index
                # update status
                key_resp_TB_Inst.status = FINISHED
                key_resp_TB_Inst.status = FINISHED
        if key_resp_TB_Inst.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_TB_Inst.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_TB_Inst_allKeys.extend(theseKeys)
            if len(_key_resp_TB_Inst_allKeys):
                key_resp_TB_Inst.keys = _key_resp_TB_Inst_allKeys[-1].name  # just the last key pressed
                key_resp_TB_Inst.rt = _key_resp_TB_Inst_allKeys[-1].rt
                key_resp_TB_Inst.duration = _key_resp_TB_Inst_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=TB_Instructions,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            TB_Instructions.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if TB_Instructions.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in TB_Instructions.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "TB_Instructions" ---
    for thisComponent in TB_Instructions.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for TB_Instructions
    TB_Instructions.tStop = globalClock.getTime(format='float')
    TB_Instructions.tStopRefresh = tThisFlipGlobal
    thisExp.addData('TB_Instructions.stopped', TB_Instructions.tStop)
    # check responses
    if key_resp_TB_Inst.keys in ['', [], None]:  # No response was made
        key_resp_TB_Inst.keys = None
    thisExp.addData('key_resp_TB_Inst.keys',key_resp_TB_Inst.keys)
    if key_resp_TB_Inst.keys != None:  # we had a response
        thisExp.addData('key_resp_TB_Inst.rt', key_resp_TB_Inst.rt)
        thisExp.addData('key_resp_TB_Inst.duration', key_resp_TB_Inst.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if TB_Instructions.maxDurationReached:
        routineTimer.addTime(-TB_Instructions.maxDuration)
    elif TB_Instructions.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-200.000000)
    thisExp.nextEntry()
    
    # --- Prepare to start Routine "TB_Inst_phase1" ---
    # create an object to store info about Routine TB_Inst_phase1
    TB_Inst_phase1 = data.Routine(
        name='TB_Inst_phase1',
        components=[text_TB1_inst, key_resp_stop_inst],
    )
    TB_Inst_phase1.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    text_TB1_inst.setText('Nesta primeira parte, você ouvirá dois sons: um curto e um longo.\n\nSeu objetivo é aprender a identificar cada duração. Cada som será repetido 5 vezes para que você possa aprender.\n\nNão é preciso apertar nenhuma tecla nesta parte, apenas preste atenção ao som e à tela.\n\nPressione a barra de espaço quando estiver pronto para iniciar.')
    # create starting attributes for key_resp_stop_inst
    key_resp_stop_inst.keys = []
    key_resp_stop_inst.rt = []
    _key_resp_stop_inst_allKeys = []
    # store start times for TB_Inst_phase1
    TB_Inst_phase1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    TB_Inst_phase1.tStart = globalClock.getTime(format='float')
    TB_Inst_phase1.status = STARTED
    thisExp.addData('TB_Inst_phase1.started', TB_Inst_phase1.tStart)
    TB_Inst_phase1.maxDuration = None
    # keep track of which components have finished
    TB_Inst_phase1Components = TB_Inst_phase1.components
    for thisComponent in TB_Inst_phase1.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "TB_Inst_phase1" ---
    thisExp.currentRoutine = TB_Inst_phase1
    TB_Inst_phase1.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 200.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_TB1_inst* updates
        
        # if text_TB1_inst is starting this frame...
        if text_TB1_inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_TB1_inst.frameNStart = frameN  # exact frame index
            text_TB1_inst.tStart = t  # local t and not account for scr refresh
            text_TB1_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_TB1_inst, 'tStartRefresh')  # time at next scr refresh
            # update status
            text_TB1_inst.status = STARTED
            text_TB1_inst.setAutoDraw(True)
        
        # if text_TB1_inst is active this frame...
        if text_TB1_inst.status == STARTED:
            # update params
            pass
        
        # if text_TB1_inst is stopping this frame...
        if text_TB1_inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_TB1_inst.tStartRefresh + 200.0-frameTolerance:
                # keep track of stop time/frame for later
                text_TB1_inst.tStop = t  # not accounting for scr refresh
                text_TB1_inst.tStopRefresh = tThisFlipGlobal  # on global time
                text_TB1_inst.frameNStop = frameN  # exact frame index
                # update status
                text_TB1_inst.status = FINISHED
                text_TB1_inst.setAutoDraw(False)
        
        # *key_resp_stop_inst* updates
        waitOnFlip = False
        
        # if key_resp_stop_inst is starting this frame...
        if key_resp_stop_inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_stop_inst.frameNStart = frameN  # exact frame index
            key_resp_stop_inst.tStart = t  # local t and not account for scr refresh
            key_resp_stop_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_stop_inst, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_stop_inst.started')
            # update status
            key_resp_stop_inst.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_stop_inst.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_stop_inst.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_resp_stop_inst is stopping this frame...
        if key_resp_stop_inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_resp_stop_inst.tStartRefresh + 200-frameTolerance:
                # keep track of stop time/frame for later
                key_resp_stop_inst.tStop = t  # not accounting for scr refresh
                key_resp_stop_inst.tStopRefresh = tThisFlipGlobal  # on global time
                key_resp_stop_inst.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_stop_inst.stopped')
                # update status
                key_resp_stop_inst.status = FINISHED
                key_resp_stop_inst.status = FINISHED
        if key_resp_stop_inst.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_stop_inst.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_stop_inst_allKeys.extend(theseKeys)
            if len(_key_resp_stop_inst_allKeys):
                key_resp_stop_inst.keys = _key_resp_stop_inst_allKeys[-1].name  # just the last key pressed
                key_resp_stop_inst.rt = _key_resp_stop_inst_allKeys[-1].rt
                key_resp_stop_inst.duration = _key_resp_stop_inst_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=TB_Inst_phase1,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            TB_Inst_phase1.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if TB_Inst_phase1.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in TB_Inst_phase1.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "TB_Inst_phase1" ---
    for thisComponent in TB_Inst_phase1.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for TB_Inst_phase1
    TB_Inst_phase1.tStop = globalClock.getTime(format='float')
    TB_Inst_phase1.tStopRefresh = tThisFlipGlobal
    thisExp.addData('TB_Inst_phase1.stopped', TB_Inst_phase1.tStop)
    # check responses
    if key_resp_stop_inst.keys in ['', [], None]:  # No response was made
        key_resp_stop_inst.keys = None
    thisExp.addData('key_resp_stop_inst.keys',key_resp_stop_inst.keys)
    if key_resp_stop_inst.keys != None:  # we had a response
        thisExp.addData('key_resp_stop_inst.rt', key_resp_stop_inst.rt)
        thisExp.addData('key_resp_stop_inst.duration', key_resp_stop_inst.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if TB_Inst_phase1.maxDurationReached:
        routineTimer.addTime(-TB_Inst_phase1.maxDuration)
    elif TB_Inst_phase1.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-200.000000)
    thisExp.nextEntry()
    
    # set up handler to look after randomisation of conditions etc
    trials_TBphase1 = data.TrialHandler2(
        name='trials_TBphase1',
        nReps=5.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=[None], 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trials_TBphase1)  # add the loop to the experiment
    thisTrials_TBphase1 = trials_TBphase1.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_TBphase1.rgb)
    if thisTrials_TBphase1 != None:
        for paramName in thisTrials_TBphase1:
            globals()[paramName] = thisTrials_TBphase1[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_TBphase1 in trials_TBphase1:
        trials_TBphase1.status = STARTED
        if hasattr(thisTrials_TBphase1, 'status'):
            thisTrials_TBphase1.status = STARTED
        currentLoop = trials_TBphase1
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_TBphase1.rgb)
        if thisTrials_TBphase1 != None:
            for paramName in thisTrials_TBphase1:
                globals()[paramName] = thisTrials_TBphase1[paramName]
        
        # --- Prepare to start Routine "TB_phase1" ---
        # create an object to store info about Routine TB_phase1
        TB_phase1 = data.Routine(
            name='TB_phase1',
            components=[text_fixation1, text_teclaq, sound_q, text_fixation2, text_teclap, sound_p],
        )
        TB_phase1.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        text_fixation1.setText('+')
        sound_q.setSound('500ms2.wav', secs=5.5, hamming=True)
        sound_q.setVolume(1.0, log=False)
        sound_q.seek(0)
        text_fixation2.setText('+')
        text_teclap.setText('LONGO (TECLA P)')
        sound_p.setSound('2000ms2.wav', secs=2, hamming=True)
        sound_p.setVolume(1.0, log=False)
        sound_p.seek(0)
        # store start times for TB_phase1
        TB_phase1.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        TB_phase1.tStart = globalClock.getTime(format='float')
        TB_phase1.status = STARTED
        thisExp.addData('TB_phase1.started', TB_phase1.tStart)
        TB_phase1.maxDuration = None
        # keep track of which components have finished
        TB_phase1Components = TB_phase1.components
        for thisComponent in TB_phase1.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "TB_phase1" ---
        thisExp.currentRoutine = TB_phase1
        TB_phase1.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 12.5:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_TBphase1, 'status') and thisTrials_TBphase1.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_fixation1* updates
            
            # if text_fixation1 is starting this frame...
            if text_fixation1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_fixation1.frameNStart = frameN  # exact frame index
                text_fixation1.tStart = t  # local t and not account for scr refresh
                text_fixation1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_fixation1, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_fixation1.started')
                # update status
                text_fixation1.status = STARTED
                text_fixation1.setAutoDraw(True)
            
            # if text_fixation1 is active this frame...
            if text_fixation1.status == STARTED:
                # update params
                pass
            
            # if text_fixation1 is stopping this frame...
            if text_fixation1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_fixation1.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    text_fixation1.tStop = t  # not accounting for scr refresh
                    text_fixation1.tStopRefresh = tThisFlipGlobal  # on global time
                    text_fixation1.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_fixation1.stopped')
                    # update status
                    text_fixation1.status = FINISHED
                    text_fixation1.setAutoDraw(False)
            
            # *text_teclaq* updates
            
            # if text_teclaq is starting this frame...
            if text_teclaq.status == NOT_STARTED and tThisFlip >= 2.0-frameTolerance:
                # keep track of start time/frame for later
                text_teclaq.frameNStart = frameN  # exact frame index
                text_teclaq.tStart = t  # local t and not account for scr refresh
                text_teclaq.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_teclaq, 'tStartRefresh')  # time at next scr refresh
                # update status
                text_teclaq.status = STARTED
                text_teclaq.setAutoDraw(True)
            
            # if text_teclaq is active this frame...
            if text_teclaq.status == STARTED:
                # update params
                pass
            
            # if text_teclaq is stopping this frame...
            if text_teclaq.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_teclaq.tStartRefresh + 3.0-frameTolerance:
                    # keep track of stop time/frame for later
                    text_teclaq.tStop = t  # not accounting for scr refresh
                    text_teclaq.tStopRefresh = tThisFlipGlobal  # on global time
                    text_teclaq.frameNStop = frameN  # exact frame index
                    # update status
                    text_teclaq.status = FINISHED
                    text_teclaq.setAutoDraw(False)
            
            # *sound_q* updates
            
            # if sound_q is starting this frame...
            if sound_q.status == NOT_STARTED and tThisFlip >= 5-frameTolerance:
                # keep track of start time/frame for later
                sound_q.frameNStart = frameN  # exact frame index
                sound_q.tStart = t  # local t and not account for scr refresh
                sound_q.tStartRefresh = tThisFlipGlobal  # on global time
                # add timestamp to datafile
                thisExp.addData('sound_q.started', tThisFlipGlobal)
                # update status
                sound_q.status = STARTED
                sound_q.play(when=win)  # sync with win flip
            
            # if sound_q is stopping this frame...
            if sound_q.status == STARTED:
                # is it time to stop? (based on local clock)
                if tThisFlip > 5.5-frameTolerance or sound_q.isFinished:
                    # keep track of stop time/frame for later
                    sound_q.tStop = t  # not accounting for scr refresh
                    sound_q.tStopRefresh = tThisFlipGlobal  # on global time
                    sound_q.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'sound_q.stopped')
                    # update status
                    sound_q.status = FINISHED
                    sound_q.stop()
            
            # *text_fixation2* updates
            
            # if text_fixation2 is starting this frame...
            if text_fixation2.status == NOT_STARTED and tThisFlip >= 5.5-frameTolerance:
                # keep track of start time/frame for later
                text_fixation2.frameNStart = frameN  # exact frame index
                text_fixation2.tStart = t  # local t and not account for scr refresh
                text_fixation2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_fixation2, 'tStartRefresh')  # time at next scr refresh
                # update status
                text_fixation2.status = STARTED
                text_fixation2.setAutoDraw(True)
            
            # if text_fixation2 is active this frame...
            if text_fixation2.status == STARTED:
                # update params
                pass
            
            # if text_fixation2 is stopping this frame...
            if text_fixation2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_fixation2.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    text_fixation2.tStop = t  # not accounting for scr refresh
                    text_fixation2.tStopRefresh = tThisFlipGlobal  # on global time
                    text_fixation2.frameNStop = frameN  # exact frame index
                    # update status
                    text_fixation2.status = FINISHED
                    text_fixation2.setAutoDraw(False)
            
            # *text_teclap* updates
            
            # if text_teclap is starting this frame...
            if text_teclap.status == NOT_STARTED and tThisFlip >= 7.5-frameTolerance:
                # keep track of start time/frame for later
                text_teclap.frameNStart = frameN  # exact frame index
                text_teclap.tStart = t  # local t and not account for scr refresh
                text_teclap.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_teclap, 'tStartRefresh')  # time at next scr refresh
                # update status
                text_teclap.status = STARTED
                text_teclap.setAutoDraw(True)
            
            # if text_teclap is active this frame...
            if text_teclap.status == STARTED:
                # update params
                pass
            
            # if text_teclap is stopping this frame...
            if text_teclap.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_teclap.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    text_teclap.tStop = t  # not accounting for scr refresh
                    text_teclap.tStopRefresh = tThisFlipGlobal  # on global time
                    text_teclap.frameNStop = frameN  # exact frame index
                    # update status
                    text_teclap.status = FINISHED
                    text_teclap.setAutoDraw(False)
            
            # *sound_p* updates
            
            # if sound_p is starting this frame...
            if sound_p.status == NOT_STARTED and tThisFlip >= 10.5-frameTolerance:
                # keep track of start time/frame for later
                sound_p.frameNStart = frameN  # exact frame index
                sound_p.tStart = t  # local t and not account for scr refresh
                sound_p.tStartRefresh = tThisFlipGlobal  # on global time
                # add timestamp to datafile
                thisExp.addData('sound_p.started', tThisFlipGlobal)
                # update status
                sound_p.status = STARTED
                sound_p.play(when=win)  # sync with win flip
            
            # if sound_p is stopping this frame...
            if sound_p.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > sound_p.tStartRefresh + 2-frameTolerance or sound_p.isFinished:
                    # keep track of stop time/frame for later
                    sound_p.tStop = t  # not accounting for scr refresh
                    sound_p.tStopRefresh = tThisFlipGlobal  # on global time
                    sound_p.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'sound_p.stopped')
                    # update status
                    sound_p.status = FINISHED
                    sound_p.stop()
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=TB_phase1,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                TB_phase1.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if TB_phase1.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in TB_phase1.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "TB_phase1" ---
        for thisComponent in TB_phase1.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for TB_phase1
        TB_phase1.tStop = globalClock.getTime(format='float')
        TB_phase1.tStopRefresh = tThisFlipGlobal
        thisExp.addData('TB_phase1.stopped', TB_phase1.tStop)
        sound_q.pause()  # ensure sound has stopped at end of Routine
        sound_p.pause()  # ensure sound has stopped at end of Routine
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if TB_phase1.maxDurationReached:
            routineTimer.addTime(-TB_phase1.maxDuration)
        elif TB_phase1.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-12.500000)
        # mark thisTrials_TBphase1 as finished
        if hasattr(thisTrials_TBphase1, 'status'):
            thisTrials_TBphase1.status = FINISHED
        # if awaiting a pause, pause now
        if trials_TBphase1.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials_TBphase1.status = STARTED
        thisExp.nextEntry()
        
    # completed 5.0 repeats of 'trials_TBphase1'
    trials_TBphase1.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "TB_Inst_phase2" ---
    # create an object to store info about Routine TB_Inst_phase2
    TB_Inst_phase2 = data.Routine(
        name='TB_Inst_phase2',
        components=[text_TB2_inst, key_resp_TBinst2_stop],
    )
    TB_Inst_phase2.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for key_resp_TBinst2_stop
    key_resp_TBinst2_stop.keys = []
    key_resp_TBinst2_stop.rt = []
    _key_resp_TBinst2_stop_allKeys = []
    # store start times for TB_Inst_phase2
    TB_Inst_phase2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    TB_Inst_phase2.tStart = globalClock.getTime(format='float')
    TB_Inst_phase2.status = STARTED
    thisExp.addData('TB_Inst_phase2.started', TB_Inst_phase2.tStart)
    TB_Inst_phase2.maxDuration = None
    # keep track of which components have finished
    TB_Inst_phase2Components = TB_Inst_phase2.components
    for thisComponent in TB_Inst_phase2.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "TB_Inst_phase2" ---
    thisExp.currentRoutine = TB_Inst_phase2
    TB_Inst_phase2.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 30.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_TB2_inst* updates
        
        # if text_TB2_inst is starting this frame...
        if text_TB2_inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_TB2_inst.frameNStart = frameN  # exact frame index
            text_TB2_inst.tStart = t  # local t and not account for scr refresh
            text_TB2_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_TB2_inst, 'tStartRefresh')  # time at next scr refresh
            # update status
            text_TB2_inst.status = STARTED
            text_TB2_inst.setAutoDraw(True)
        
        # if text_TB2_inst is active this frame...
        if text_TB2_inst.status == STARTED:
            # update params
            pass
        
        # if text_TB2_inst is stopping this frame...
        if text_TB2_inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_TB2_inst.tStartRefresh + 30.0-frameTolerance:
                # keep track of stop time/frame for later
                text_TB2_inst.tStop = t  # not accounting for scr refresh
                text_TB2_inst.tStopRefresh = tThisFlipGlobal  # on global time
                text_TB2_inst.frameNStop = frameN  # exact frame index
                # update status
                text_TB2_inst.status = FINISHED
                text_TB2_inst.setAutoDraw(False)
        
        # *key_resp_TBinst2_stop* updates
        waitOnFlip = False
        
        # if key_resp_TBinst2_stop is starting this frame...
        if key_resp_TBinst2_stop.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_TBinst2_stop.frameNStart = frameN  # exact frame index
            key_resp_TBinst2_stop.tStart = t  # local t and not account for scr refresh
            key_resp_TBinst2_stop.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_TBinst2_stop, 'tStartRefresh')  # time at next scr refresh
            # update status
            key_resp_TBinst2_stop.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_TBinst2_stop.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_TBinst2_stop.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_resp_TBinst2_stop is stopping this frame...
        if key_resp_TBinst2_stop.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_resp_TBinst2_stop.tStartRefresh + 30-frameTolerance:
                # keep track of stop time/frame for later
                key_resp_TBinst2_stop.tStop = t  # not accounting for scr refresh
                key_resp_TBinst2_stop.tStopRefresh = tThisFlipGlobal  # on global time
                key_resp_TBinst2_stop.frameNStop = frameN  # exact frame index
                # update status
                key_resp_TBinst2_stop.status = FINISHED
                key_resp_TBinst2_stop.status = FINISHED
        if key_resp_TBinst2_stop.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_TBinst2_stop.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_TBinst2_stop_allKeys.extend(theseKeys)
            if len(_key_resp_TBinst2_stop_allKeys):
                key_resp_TBinst2_stop.keys = _key_resp_TBinst2_stop_allKeys[-1].name  # just the last key pressed
                key_resp_TBinst2_stop.rt = _key_resp_TBinst2_stop_allKeys[-1].rt
                key_resp_TBinst2_stop.duration = _key_resp_TBinst2_stop_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=TB_Inst_phase2,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            TB_Inst_phase2.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if TB_Inst_phase2.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in TB_Inst_phase2.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "TB_Inst_phase2" ---
    for thisComponent in TB_Inst_phase2.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for TB_Inst_phase2
    TB_Inst_phase2.tStop = globalClock.getTime(format='float')
    TB_Inst_phase2.tStopRefresh = tThisFlipGlobal
    thisExp.addData('TB_Inst_phase2.stopped', TB_Inst_phase2.tStop)
    # check responses
    if key_resp_TBinst2_stop.keys in ['', [], None]:  # No response was made
        key_resp_TBinst2_stop.keys = None
    thisExp.addData('key_resp_TBinst2_stop.keys',key_resp_TBinst2_stop.keys)
    if key_resp_TBinst2_stop.keys != None:  # we had a response
        thisExp.addData('key_resp_TBinst2_stop.rt', key_resp_TBinst2_stop.rt)
        thisExp.addData('key_resp_TBinst2_stop.duration', key_resp_TBinst2_stop.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if TB_Inst_phase2.maxDurationReached:
        routineTimer.addTime(-TB_Inst_phase2.maxDuration)
    elif TB_Inst_phase2.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-30.000000)
    thisExp.nextEntry()
    
    # set up handler to look after randomisation of conditions etc
    trials_TBphase2 = data.TrialHandler2(
        name='trials_TBphase2',
        nReps=40.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('Condicoes_tempo_updated.csv'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trials_TBphase2)  # add the loop to the experiment
    thisTrials_TBphase2 = trials_TBphase2.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_TBphase2.rgb)
    if thisTrials_TBphase2 != None:
        for paramName in thisTrials_TBphase2:
            globals()[paramName] = thisTrials_TBphase2[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_TBphase2 in trials_TBphase2:
        trials_TBphase2.status = STARTED
        if hasattr(thisTrials_TBphase2, 'status'):
            thisTrials_TBphase2.status = STARTED
        currentLoop = trials_TBphase2
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_TBphase2.rgb)
        if thisTrials_TBphase2 != None:
            for paramName in thisTrials_TBphase2:
                globals()[paramName] = thisTrials_TBphase2[paramName]
        
        # --- Prepare to start Routine "spacer_phase2" ---
        # create an object to store info about Routine spacer_phase2
        spacer_phase2 = data.Routine(
            name='spacer_phase2',
            components=[text_fixation_phase2],
        )
        spacer_phase2.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        text_fixation_phase2.setText('+\n')
        # Run 'Begin Routine' code from spacer_phase2_code
        # Primeiro cria a variável (se ela ainda não existir)
        if not hasattr(thisExp, 'correct_count'):
            thisExp.correct_count = 0
        
        # Depois verifica se já atingiu 10 acertos
        if thisExp.correct_count >= 10:
            continueRoutine = False
        # store start times for spacer_phase2
        spacer_phase2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        spacer_phase2.tStart = globalClock.getTime(format='float')
        spacer_phase2.status = STARTED
        thisExp.addData('spacer_phase2.started', spacer_phase2.tStart)
        spacer_phase2.maxDuration = None
        # keep track of which components have finished
        spacer_phase2Components = spacer_phase2.components
        for thisComponent in spacer_phase2.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "spacer_phase2" ---
        thisExp.currentRoutine = spacer_phase2
        spacer_phase2.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_TBphase2, 'status') and thisTrials_TBphase2.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_fixation_phase2* updates
            
            # if text_fixation_phase2 is starting this frame...
            if text_fixation_phase2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_fixation_phase2.frameNStart = frameN  # exact frame index
                text_fixation_phase2.tStart = t  # local t and not account for scr refresh
                text_fixation_phase2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_fixation_phase2, 'tStartRefresh')  # time at next scr refresh
                # update status
                text_fixation_phase2.status = STARTED
                text_fixation_phase2.setAutoDraw(True)
            
            # if text_fixation_phase2 is active this frame...
            if text_fixation_phase2.status == STARTED:
                # update params
                pass
            
            # if text_fixation_phase2 is stopping this frame...
            if text_fixation_phase2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_fixation_phase2.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    text_fixation_phase2.tStop = t  # not accounting for scr refresh
                    text_fixation_phase2.tStopRefresh = tThisFlipGlobal  # on global time
                    text_fixation_phase2.frameNStop = frameN  # exact frame index
                    # update status
                    text_fixation_phase2.status = FINISHED
                    text_fixation_phase2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=spacer_phase2,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                spacer_phase2.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if spacer_phase2.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in spacer_phase2.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "spacer_phase2" ---
        for thisComponent in spacer_phase2.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for spacer_phase2
        spacer_phase2.tStop = globalClock.getTime(format='float')
        spacer_phase2.tStopRefresh = tThisFlipGlobal
        thisExp.addData('spacer_phase2.stopped', spacer_phase2.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if spacer_phase2.maxDurationReached:
            routineTimer.addTime(-spacer_phase2.maxDuration)
        elif spacer_phase2.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.000000)
        
        # --- Prepare to start Routine "trial_phase2" ---
        # create an object to store info about Routine trial_phase2
        trial_phase2 = data.Routine(
            name='trial_phase2',
            components=[sound_phase2],
        )
        trial_phase2.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        sound_phase2.setSound(stimulus, secs=duration, hamming=True)
        sound_phase2.setVolume(1.0, log=False)
        sound_phase2.seek(0)
        # Run 'Begin Routine' code from trial_phase2_code
        # Primeiro cria a variável (se ela ainda não existir)
        if not hasattr(thisExp, 'correct_count'):
            thisExp.correct_count = 0
        
        # Depois verifica se já atingiu 10 acertos
        if thisExp.correct_count >= 10:
            continueRoutine = False
            
        # store start times for trial_phase2
        trial_phase2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        trial_phase2.tStart = globalClock.getTime(format='float')
        trial_phase2.status = STARTED
        thisExp.addData('trial_phase2.started', trial_phase2.tStart)
        trial_phase2.maxDuration = None
        # keep track of which components have finished
        trial_phase2Components = trial_phase2.components
        for thisComponent in trial_phase2.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "trial_phase2" ---
        thisExp.currentRoutine = trial_phase2
        trial_phase2.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_TBphase2, 'status') and thisTrials_TBphase2.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *sound_phase2* updates
            
            # if sound_phase2 is starting this frame...
            if sound_phase2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sound_phase2.frameNStart = frameN  # exact frame index
                sound_phase2.tStart = t  # local t and not account for scr refresh
                sound_phase2.tStartRefresh = tThisFlipGlobal  # on global time
                # add timestamp to datafile
                thisExp.addData('sound_phase2.started', tThisFlipGlobal)
                # update status
                sound_phase2.status = STARTED
                sound_phase2.play(when=win)  # sync with win flip
            
            # if sound_phase2 is stopping this frame...
            if sound_phase2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > sound_phase2.tStartRefresh + duration-frameTolerance or sound_phase2.isFinished:
                    # keep track of stop time/frame for later
                    sound_phase2.tStop = t  # not accounting for scr refresh
                    sound_phase2.tStopRefresh = tThisFlipGlobal  # on global time
                    sound_phase2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'sound_phase2.stopped')
                    # update status
                    sound_phase2.status = FINISHED
                    sound_phase2.stop()
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=trial_phase2,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                trial_phase2.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if trial_phase2.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in trial_phase2.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "trial_phase2" ---
        for thisComponent in trial_phase2.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for trial_phase2
        trial_phase2.tStop = globalClock.getTime(format='float')
        trial_phase2.tStopRefresh = tThisFlipGlobal
        thisExp.addData('trial_phase2.stopped', trial_phase2.tStop)
        sound_phase2.pause()  # ensure sound has stopped at end of Routine
        # the Routine "trial_phase2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "response_phase2" ---
        # create an object to store info about Routine response_phase2
        response_phase2 = data.Routine(
            name='response_phase2',
            components=[text_resp_phase2, key_resp_phase2],
        )
        response_phase2.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        text_resp_phase2.setText('Curto(Q) ou Longo(P)?')
        # create starting attributes for key_resp_phase2
        key_resp_phase2.keys = []
        key_resp_phase2.rt = []
        _key_resp_phase2_allKeys = []
        # Run 'Begin Routine' code from code_phase2
        # Inicializar a contagem de respostas corretas
        if not hasattr(thisExp, 'correct_count'):
            thisExp.correct_count = 0  # Inicializa a contagem
        
        if thisExp.correct_count >= 10:
            continueRoutine = False
        # store start times for response_phase2
        response_phase2.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        response_phase2.tStart = globalClock.getTime(format='float')
        response_phase2.status = STARTED
        thisExp.addData('response_phase2.started', response_phase2.tStart)
        response_phase2.maxDuration = None
        # keep track of which components have finished
        response_phase2Components = response_phase2.components
        for thisComponent in response_phase2.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "response_phase2" ---
        thisExp.currentRoutine = response_phase2
        response_phase2.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 10.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_TBphase2, 'status') and thisTrials_TBphase2.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_resp_phase2* updates
            
            # if text_resp_phase2 is starting this frame...
            if text_resp_phase2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_resp_phase2.frameNStart = frameN  # exact frame index
                text_resp_phase2.tStart = t  # local t and not account for scr refresh
                text_resp_phase2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_resp_phase2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_resp_phase2.started')
                # update status
                text_resp_phase2.status = STARTED
                text_resp_phase2.setAutoDraw(True)
            
            # if text_resp_phase2 is active this frame...
            if text_resp_phase2.status == STARTED:
                # update params
                pass
            
            # if text_resp_phase2 is stopping this frame...
            if text_resp_phase2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_resp_phase2.tStartRefresh + 10-frameTolerance:
                    # keep track of stop time/frame for later
                    text_resp_phase2.tStop = t  # not accounting for scr refresh
                    text_resp_phase2.tStopRefresh = tThisFlipGlobal  # on global time
                    text_resp_phase2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_resp_phase2.stopped')
                    # update status
                    text_resp_phase2.status = FINISHED
                    text_resp_phase2.setAutoDraw(False)
            
            # *key_resp_phase2* updates
            waitOnFlip = False
            
            # if key_resp_phase2 is starting this frame...
            if key_resp_phase2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_phase2.frameNStart = frameN  # exact frame index
                key_resp_phase2.tStart = t  # local t and not account for scr refresh
                key_resp_phase2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_phase2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_phase2.started')
                # update status
                key_resp_phase2.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_phase2.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_phase2.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_resp_phase2 is stopping this frame...
            if key_resp_phase2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_resp_phase2.tStartRefresh + 10-frameTolerance:
                    # keep track of stop time/frame for later
                    key_resp_phase2.tStop = t  # not accounting for scr refresh
                    key_resp_phase2.tStopRefresh = tThisFlipGlobal  # on global time
                    key_resp_phase2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_phase2.stopped')
                    # update status
                    key_resp_phase2.status = FINISHED
                    key_resp_phase2.status = FINISHED
            if key_resp_phase2.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_phase2.getKeys(keyList=['q','p'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_phase2_allKeys.extend(theseKeys)
                if len(_key_resp_phase2_allKeys):
                    key_resp_phase2.keys = _key_resp_phase2_allKeys[-1].name  # just the last key pressed
                    key_resp_phase2.rt = _key_resp_phase2_allKeys[-1].rt
                    key_resp_phase2.duration = _key_resp_phase2_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=response_phase2,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                response_phase2.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if response_phase2.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in response_phase2.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "response_phase2" ---
        for thisComponent in response_phase2.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for response_phase2
        response_phase2.tStop = globalClock.getTime(format='float')
        response_phase2.tStopRefresh = tThisFlipGlobal
        thisExp.addData('response_phase2.stopped', response_phase2.tStop)
        # check responses
        if key_resp_phase2.keys in ['', [], None]:  # No response was made
            key_resp_phase2.keys = None
        trials_TBphase2.addData('key_resp_phase2.keys',key_resp_phase2.keys)
        if key_resp_phase2.keys != None:  # we had a response
            trials_TBphase2.addData('key_resp_phase2.rt', key_resp_phase2.rt)
            trials_TBphase2.addData('key_resp_phase2.duration', key_resp_phase2.duration)
        # Run 'End Routine' code from code_phase2
        # Verifica se a tecla pressionada corresponde à resposta correta
        if key_resp_phase2.keys == correct_response:  # Substitua 'correct_response' pelo nome correto da sua coluna no arquivo de condições
            thisExp.correct_count += 1  # Aumenta o contador de respostas corretas
        
        
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if response_phase2.maxDurationReached:
            routineTimer.addTime(-response_phase2.maxDuration)
        elif response_phase2.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-10.000000)
        # mark thisTrials_TBphase2 as finished
        if hasattr(thisTrials_TBphase2, 'status'):
            thisTrials_TBphase2.status = FINISHED
        # if awaiting a pause, pause now
        if trials_TBphase2.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials_TBphase2.status = STARTED
        thisExp.nextEntry()
        
    # completed 40.0 repeats of 'trials_TBphase2'
    trials_TBphase2.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "TB_Inst_phase3" ---
    # create an object to store info about Routine TB_Inst_phase3
    TB_Inst_phase3 = data.Routine(
        name='TB_Inst_phase3',
        components=[text_TB3_inst, key_resp_inst_phase3],
    )
    TB_Inst_phase3.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    text_TB3_inst.setText('Por último, além dos sons curto e longo, serão apresentados também sons intermediários.\n\nSeu objetivo é decidir, para cada som, se ele se parece mais com um curto ou com um longo. Você terá 10 segundos após ouvir o som para decidir e pressionar a tecla.\n\nPressione a barra de espaço quando estiver pronto(a) para começar.\n')
    # create starting attributes for key_resp_inst_phase3
    key_resp_inst_phase3.keys = []
    key_resp_inst_phase3.rt = []
    _key_resp_inst_phase3_allKeys = []
    # store start times for TB_Inst_phase3
    TB_Inst_phase3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    TB_Inst_phase3.tStart = globalClock.getTime(format='float')
    TB_Inst_phase3.status = STARTED
    thisExp.addData('TB_Inst_phase3.started', TB_Inst_phase3.tStart)
    TB_Inst_phase3.maxDuration = None
    # keep track of which components have finished
    TB_Inst_phase3Components = TB_Inst_phase3.components
    for thisComponent in TB_Inst_phase3.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "TB_Inst_phase3" ---
    thisExp.currentRoutine = TB_Inst_phase3
    TB_Inst_phase3.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 200.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_TB3_inst* updates
        
        # if text_TB3_inst is starting this frame...
        if text_TB3_inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_TB3_inst.frameNStart = frameN  # exact frame index
            text_TB3_inst.tStart = t  # local t and not account for scr refresh
            text_TB3_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_TB3_inst, 'tStartRefresh')  # time at next scr refresh
            # update status
            text_TB3_inst.status = STARTED
            text_TB3_inst.setAutoDraw(True)
        
        # if text_TB3_inst is active this frame...
        if text_TB3_inst.status == STARTED:
            # update params
            pass
        
        # if text_TB3_inst is stopping this frame...
        if text_TB3_inst.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_TB3_inst.tStartRefresh + 200-frameTolerance:
                # keep track of stop time/frame for later
                text_TB3_inst.tStop = t  # not accounting for scr refresh
                text_TB3_inst.tStopRefresh = tThisFlipGlobal  # on global time
                text_TB3_inst.frameNStop = frameN  # exact frame index
                # update status
                text_TB3_inst.status = FINISHED
                text_TB3_inst.setAutoDraw(False)
        
        # *key_resp_inst_phase3* updates
        waitOnFlip = False
        
        # if key_resp_inst_phase3 is starting this frame...
        if key_resp_inst_phase3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_inst_phase3.frameNStart = frameN  # exact frame index
            key_resp_inst_phase3.tStart = t  # local t and not account for scr refresh
            key_resp_inst_phase3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_inst_phase3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp_inst_phase3.started')
            # update status
            key_resp_inst_phase3.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_inst_phase3.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_inst_phase3.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_resp_inst_phase3 is stopping this frame...
        if key_resp_inst_phase3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_resp_inst_phase3.tStartRefresh + 200-frameTolerance:
                # keep track of stop time/frame for later
                key_resp_inst_phase3.tStop = t  # not accounting for scr refresh
                key_resp_inst_phase3.tStopRefresh = tThisFlipGlobal  # on global time
                key_resp_inst_phase3.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_inst_phase3.stopped')
                # update status
                key_resp_inst_phase3.status = FINISHED
                key_resp_inst_phase3.status = FINISHED
        if key_resp_inst_phase3.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_inst_phase3.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _key_resp_inst_phase3_allKeys.extend(theseKeys)
            if len(_key_resp_inst_phase3_allKeys):
                key_resp_inst_phase3.keys = _key_resp_inst_phase3_allKeys[-1].name  # just the last key pressed
                key_resp_inst_phase3.rt = _key_resp_inst_phase3_allKeys[-1].rt
                key_resp_inst_phase3.duration = _key_resp_inst_phase3_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=TB_Inst_phase3,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            TB_Inst_phase3.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if TB_Inst_phase3.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in TB_Inst_phase3.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "TB_Inst_phase3" ---
    for thisComponent in TB_Inst_phase3.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for TB_Inst_phase3
    TB_Inst_phase3.tStop = globalClock.getTime(format='float')
    TB_Inst_phase3.tStopRefresh = tThisFlipGlobal
    thisExp.addData('TB_Inst_phase3.stopped', TB_Inst_phase3.tStop)
    # check responses
    if key_resp_inst_phase3.keys in ['', [], None]:  # No response was made
        key_resp_inst_phase3.keys = None
    thisExp.addData('key_resp_inst_phase3.keys',key_resp_inst_phase3.keys)
    if key_resp_inst_phase3.keys != None:  # we had a response
        thisExp.addData('key_resp_inst_phase3.rt', key_resp_inst_phase3.rt)
        thisExp.addData('key_resp_inst_phase3.duration', key_resp_inst_phase3.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if TB_Inst_phase3.maxDurationReached:
        routineTimer.addTime(-TB_Inst_phase3.maxDuration)
    elif TB_Inst_phase3.forceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-200.000000)
    thisExp.nextEntry()
    
    # set up handler to look after randomisation of conditions etc
    trials_phase3 = data.TrialHandler2(
        name='trials_phase3',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('condicoes_fasefinal_temporal_updated .csv'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(trials_phase3)  # add the loop to the experiment
    thisTrials_phase3 = trials_phase3.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_phase3.rgb)
    if thisTrials_phase3 != None:
        for paramName in thisTrials_phase3:
            globals()[paramName] = thisTrials_phase3[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisTrials_phase3 in trials_phase3:
        trials_phase3.status = STARTED
        if hasattr(thisTrials_phase3, 'status'):
            thisTrials_phase3.status = STARTED
        currentLoop = trials_phase3
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_phase3.rgb)
        if thisTrials_phase3 != None:
            for paramName in thisTrials_phase3:
                globals()[paramName] = thisTrials_phase3[paramName]
        
        # --- Prepare to start Routine "spacer_phase3" ---
        # create an object to store info about Routine spacer_phase3
        spacer_phase3 = data.Routine(
            name='spacer_phase3',
            components=[text_spacer_phase3],
        )
        spacer_phase3.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # store start times for spacer_phase3
        spacer_phase3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        spacer_phase3.tStart = globalClock.getTime(format='float')
        spacer_phase3.status = STARTED
        thisExp.addData('spacer_phase3.started', spacer_phase3.tStart)
        spacer_phase3.maxDuration = None
        # keep track of which components have finished
        spacer_phase3Components = spacer_phase3.components
        for thisComponent in spacer_phase3.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "spacer_phase3" ---
        thisExp.currentRoutine = spacer_phase3
        spacer_phase3.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_phase3, 'status') and thisTrials_phase3.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_spacer_phase3* updates
            
            # if text_spacer_phase3 is starting this frame...
            if text_spacer_phase3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_spacer_phase3.frameNStart = frameN  # exact frame index
                text_spacer_phase3.tStart = t  # local t and not account for scr refresh
                text_spacer_phase3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_spacer_phase3, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_spacer_phase3.started')
                # update status
                text_spacer_phase3.status = STARTED
                text_spacer_phase3.setAutoDraw(True)
            
            # if text_spacer_phase3 is active this frame...
            if text_spacer_phase3.status == STARTED:
                # update params
                pass
            
            # if text_spacer_phase3 is stopping this frame...
            if text_spacer_phase3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_spacer_phase3.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    text_spacer_phase3.tStop = t  # not accounting for scr refresh
                    text_spacer_phase3.tStopRefresh = tThisFlipGlobal  # on global time
                    text_spacer_phase3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_spacer_phase3.stopped')
                    # update status
                    text_spacer_phase3.status = FINISHED
                    text_spacer_phase3.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=spacer_phase3,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                spacer_phase3.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if spacer_phase3.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in spacer_phase3.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "spacer_phase3" ---
        for thisComponent in spacer_phase3.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for spacer_phase3
        spacer_phase3.tStop = globalClock.getTime(format='float')
        spacer_phase3.tStopRefresh = tThisFlipGlobal
        thisExp.addData('spacer_phase3.stopped', spacer_phase3.tStop)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if spacer_phase3.maxDurationReached:
            routineTimer.addTime(-spacer_phase3.maxDuration)
        elif spacer_phase3.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.000000)
        
        # --- Prepare to start Routine "trial_phase3" ---
        # create an object to store info about Routine trial_phase3
        trial_phase3 = data.Routine(
            name='trial_phase3',
            components=[sound_phase3],
        )
        trial_phase3.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        sound_phase3.setSound(stimulus, secs=duration, hamming=True)
        sound_phase3.setVolume(1.0, log=False)
        sound_phase3.seek(0)
        # store start times for trial_phase3
        trial_phase3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        trial_phase3.tStart = globalClock.getTime(format='float')
        trial_phase3.status = STARTED
        thisExp.addData('trial_phase3.started', trial_phase3.tStart)
        trial_phase3.maxDuration = None
        # keep track of which components have finished
        trial_phase3Components = trial_phase3.components
        for thisComponent in trial_phase3.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "trial_phase3" ---
        thisExp.currentRoutine = trial_phase3
        trial_phase3.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_phase3, 'status') and thisTrials_phase3.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *sound_phase3* updates
            
            # if sound_phase3 is starting this frame...
            if sound_phase3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sound_phase3.frameNStart = frameN  # exact frame index
                sound_phase3.tStart = t  # local t and not account for scr refresh
                sound_phase3.tStartRefresh = tThisFlipGlobal  # on global time
                # add timestamp to datafile
                thisExp.addData('sound_phase3.started', tThisFlipGlobal)
                # update status
                sound_phase3.status = STARTED
                sound_phase3.play(when=win)  # sync with win flip
            
            # if sound_phase3 is stopping this frame...
            if sound_phase3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > sound_phase3.tStartRefresh + duration-frameTolerance or sound_phase3.isFinished:
                    # keep track of stop time/frame for later
                    sound_phase3.tStop = t  # not accounting for scr refresh
                    sound_phase3.tStopRefresh = tThisFlipGlobal  # on global time
                    sound_phase3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'sound_phase3.stopped')
                    # update status
                    sound_phase3.status = FINISHED
                    sound_phase3.stop()
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=trial_phase3,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                trial_phase3.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if trial_phase3.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in trial_phase3.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "trial_phase3" ---
        for thisComponent in trial_phase3.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for trial_phase3
        trial_phase3.tStop = globalClock.getTime(format='float')
        trial_phase3.tStopRefresh = tThisFlipGlobal
        thisExp.addData('trial_phase3.stopped', trial_phase3.tStop)
        sound_phase3.pause()  # ensure sound has stopped at end of Routine
        # the Routine "trial_phase3" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "response_phase3" ---
        # create an object to store info about Routine response_phase3
        response_phase3 = data.Routine(
            name='response_phase3',
            components=[text_response_phase3, key_resp_phase3],
        )
        response_phase3.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        text_response_phase3.setText('Curto (Q) ou Longo(P)?')
        # create starting attributes for key_resp_phase3
        key_resp_phase3.keys = []
        key_resp_phase3.rt = []
        _key_resp_phase3_allKeys = []
        # store start times for response_phase3
        response_phase3.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        response_phase3.tStart = globalClock.getTime(format='float')
        response_phase3.status = STARTED
        thisExp.addData('response_phase3.started', response_phase3.tStart)
        response_phase3.maxDuration = None
        # keep track of which components have finished
        response_phase3Components = response_phase3.components
        for thisComponent in response_phase3.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "response_phase3" ---
        thisExp.currentRoutine = response_phase3
        response_phase3.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 10.0:
            # if trial has changed, end Routine now
            if hasattr(thisTrials_phase3, 'status') and thisTrials_phase3.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_response_phase3* updates
            
            # if text_response_phase3 is starting this frame...
            if text_response_phase3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_response_phase3.frameNStart = frameN  # exact frame index
                text_response_phase3.tStart = t  # local t and not account for scr refresh
                text_response_phase3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_response_phase3, 'tStartRefresh')  # time at next scr refresh
                # update status
                text_response_phase3.status = STARTED
                text_response_phase3.setAutoDraw(True)
            
            # if text_response_phase3 is active this frame...
            if text_response_phase3.status == STARTED:
                # update params
                pass
            
            # if text_response_phase3 is stopping this frame...
            if text_response_phase3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_response_phase3.tStartRefresh + 10-frameTolerance:
                    # keep track of stop time/frame for later
                    text_response_phase3.tStop = t  # not accounting for scr refresh
                    text_response_phase3.tStopRefresh = tThisFlipGlobal  # on global time
                    text_response_phase3.frameNStop = frameN  # exact frame index
                    # update status
                    text_response_phase3.status = FINISHED
                    text_response_phase3.setAutoDraw(False)
            
            # *key_resp_phase3* updates
            waitOnFlip = False
            
            # if key_resp_phase3 is starting this frame...
            if key_resp_phase3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                key_resp_phase3.frameNStart = frameN  # exact frame index
                key_resp_phase3.tStart = t  # local t and not account for scr refresh
                key_resp_phase3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_phase3, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_phase3.started')
                # update status
                key_resp_phase3.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_phase3.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_phase3.clearEvents, eventType='keyboard')  # clear events on next screen flip
            
            # if key_resp_phase3 is stopping this frame...
            if key_resp_phase3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > key_resp_phase3.tStartRefresh + 10-frameTolerance:
                    # keep track of stop time/frame for later
                    key_resp_phase3.tStop = t  # not accounting for scr refresh
                    key_resp_phase3.tStopRefresh = tThisFlipGlobal  # on global time
                    key_resp_phase3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_phase3.stopped')
                    # update status
                    key_resp_phase3.status = FINISHED
                    key_resp_phase3.status = FINISHED
            if key_resp_phase3.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_phase3.getKeys(keyList=['q','p'], ignoreKeys=["escape"], waitRelease=False)
                _key_resp_phase3_allKeys.extend(theseKeys)
                if len(_key_resp_phase3_allKeys):
                    key_resp_phase3.keys = _key_resp_phase3_allKeys[-1].name  # just the last key pressed
                    key_resp_phase3.rt = _key_resp_phase3_allKeys[-1].rt
                    key_resp_phase3.duration = _key_resp_phase3_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=response_phase3,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                response_phase3.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if response_phase3.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in response_phase3.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "response_phase3" ---
        for thisComponent in response_phase3.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for response_phase3
        response_phase3.tStop = globalClock.getTime(format='float')
        response_phase3.tStopRefresh = tThisFlipGlobal
        thisExp.addData('response_phase3.stopped', response_phase3.tStop)
        # check responses
        if key_resp_phase3.keys in ['', [], None]:  # No response was made
            key_resp_phase3.keys = None
        trials_phase3.addData('key_resp_phase3.keys',key_resp_phase3.keys)
        if key_resp_phase3.keys != None:  # we had a response
            trials_phase3.addData('key_resp_phase3.rt', key_resp_phase3.rt)
            trials_phase3.addData('key_resp_phase3.duration', key_resp_phase3.duration)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if response_phase3.maxDurationReached:
            routineTimer.addTime(-response_phase3.maxDuration)
        elif response_phase3.forceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-10.000000)
        # mark thisTrials_phase3 as finished
        if hasattr(thisTrials_phase3, 'status'):
            thisTrials_phase3.status = FINISHED
        # if awaiting a pause, pause now
        if trials_phase3.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            trials_phase3.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trials_phase3'
    trials_phase3.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    # --- Prepare to start Routine "End" ---
    # create an object to store info about Routine End
    End = data.Routine(
        name='End',
        components=[text_end, end_key],
    )
    End.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for end_key
    end_key.keys = []
    end_key.rt = []
    _end_key_allKeys = []
    # store start times for End
    End.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    End.tStart = globalClock.getTime(format='float')
    End.status = STARTED
    thisExp.addData('End.started', End.tStart)
    End.maxDuration = None
    # keep track of which components have finished
    EndComponents = End.components
    for thisComponent in End.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "End" ---
    thisExp.currentRoutine = End
    End.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_end* updates
        
        # if text_end is starting this frame...
        if text_end.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_end.frameNStart = frameN  # exact frame index
            text_end.tStart = t  # local t and not account for scr refresh
            text_end.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_end, 'tStartRefresh')  # time at next scr refresh
            # update status
            text_end.status = STARTED
            text_end.setAutoDraw(True)
        
        # if text_end is active this frame...
        if text_end.status == STARTED:
            # update params
            pass
        
        # *end_key* updates
        waitOnFlip = False
        
        # if end_key is starting this frame...
        if end_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            end_key.frameNStart = frameN  # exact frame index
            end_key.tStart = t  # local t and not account for scr refresh
            end_key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(end_key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'end_key.started')
            # update status
            end_key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(end_key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(end_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if end_key.status == STARTED and not waitOnFlip:
            theseKeys = end_key.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _end_key_allKeys.extend(theseKeys)
            if len(_end_key_allKeys):
                end_key.keys = _end_key_allKeys[-1].name  # just the last key pressed
                end_key.rt = _end_key_allKeys[-1].rt
                end_key.duration = _end_key_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=End,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            End.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if End.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in End.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "End" ---
    for thisComponent in End.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for End
    End.tStop = globalClock.getTime(format='float')
    End.tStopRefresh = tThisFlipGlobal
    thisExp.addData('End.stopped', End.tStop)
    # check responses
    if end_key.keys in ['', [], None]:  # No response was made
        end_key.keys = None
    thisExp.addData('end_key.keys',end_key.keys)
    if end_key.keys != None:  # we had a response
        thisExp.addData('end_key.rt', end_key.rt)
        thisExp.addData('end_key.duration', end_key.duration)
    thisExp.nextEntry()
    # the Routine "End" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    # stop any playback components
    if thisExp.currentRoutine is not None:
        for comp in thisExp.currentRoutine.getPlaybackComponents():
            comp.stop()
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
